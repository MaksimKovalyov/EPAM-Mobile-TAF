/*
 * Created on Mar 21, 2006
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package docs.samples.JChart;

import java.awt.Dimension;

import com.extentech.ExtenXLS.ChartHandle;
import com.extentech.ExtenXLS.ui.jchart.*;
import com.extentech.ExtenXLS.*;

/**
 * Test for JChart.
 */
public class testJChart {

	private static ChartHandle lineChart;
	private static ChartHandle barChart;
	private static ChartHandle pieChart;
	/**
	 * Set up the test. 
	 */
	private static void setUp(){
		//Set up a bar chart
		barChart = new ChartHandle();
		barChart.setChartType("Bar");
		barChart.setChartTitle("This is a Bar Chart");
		barChart.setXAxisTitle("X Axis");
		barChart.setYAxisTitle("Y Axis");
		barChart.setXSeries("Sheet1!A1:A10");
		barChart.setYSeries("Sheet1!B1:B10");
		barChart.setGridLinesPref(true);
		// 20080417 KSC: wrong method: need setCoords barChart.setChartDimension(new Dimension(JChart.DEFAULT_WIDTH,JChart.DEFAULT_HEIGHT));
	}
	
	/**
	 * Display the three different chart types.
	 */
	public static void main(String[] args) {
		setUp();
		//JChart bar = new JChart(barChart);
		//bar.display();
	}
	

}
