﻿package docs.samples.Dates;

import java.io.BufferedOutputStream;
import java.io.FileOutputStream;
import java.sql.Date;
import java.util.*;
import java.text.*;

import com.extentech.ExtenXLS.*;
import com.extentech.formats.XLS.CellNotFoundException;
import com.extentech.formats.XLS.WorkSheetNotFoundException;
import com.extentech.toolkit.Logger;

/* Copyright 2007 Extentech Inc.
EXTENTECH SOFTWARE LICENSE AGREEMENT

All Java classes and other files contained in the com.extentech package are protected
by copyright and are the sole property of Extentech Inc.

This software may be used only by Extentech customers and may not be copied, sold, distributed
or used for any other purpose without the prior written consent of Extentech.  Those
interested in licensing components, servlets, and utility classes separately from the Luminet
Server product should contact Extentech Inc. at sales@extentech.com.

You agree that you will not reverse-engineer, or decompile the compiled files distributed with
this program with the exception of open-source servlets and other files with which source code
is included in the distribution.

To the maximum extent permitted by law, Extentech Inc. disclaims all warranties regarding
this software, expressed or implied, including but not limited to warranties of merchantability
and fitness for a particular purpose. In no event shall Extentech be liable for special,
consequential, incidental or indirect damages arising out of the use or inability
to use this software even if Extentech Inc. is aware of the possibility of such
damages or known defects.

This software is provided AS IS.
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.

By using this software, you are agreeing to all of the terms of this license.
****************************************************/

/**  This Class Demonstrates the basic functionality of of ExtenXLS Date Handling


    @author John McMahon -- Copyright &copy;2007 <a href = "http://www.extentech.com">Extentech Inc.</a>
    @version 5.1
	@since 1.3
*/
public class TestDateHandling{

    public static void main(String[] args){
        testDates t = new testDates();
		t.testit();
    }
}

/** Test the creation of a new Workbook with 3 worksheets.
*/
class testDates{
	String wd = "C:/ExtenXLS6/docs/samples/Dates/";
    String  file = wd+"testdates.xls", sheetname = "Sheet1";
    int ROWHEIGHT   = 100;    
    int NUMADDS     = 100;    
    WorkBookHandle book = null;
    WorkSheetHandle sheet = null;
    
    void testit(){
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
      	book = new WorkBookHandle(file);
        try{
            sheet = book.getWorkSheet(sheetname);
        }catch(WorkSheetNotFoundException e){Logger.logErr(e);}
        
        // get a date-time
        CellHandle a1 = null, a2 = null, a3 = null;
        int GMT_FORMAT = -1;
        try{
           a1 = sheet.getCell("a1");
           GMT_FORMAT = a1.getFormatId();
           a2 = sheet.getCell("a2");
           a3 = sheet.getCell("a3");
        }catch(CellNotFoundException e){Logger.logErr(e);}
        
        Logger.logInfo(sdf.format(DateConverter.getDateFromCell(a1)));
        Logger.logInfo(sdf.format(DateConverter.getDateFromCell(a2)));
        Logger.logInfo(sdf.format(DateConverter.getDateFromCell(a3)));
        
        // add new date to cells
        CellHandle a6 = sheet.add(new Date(System.currentTimeMillis()),"a6");
        Logger.logInfo(a6.getFormattedStringVal());
        
        CellHandle a7 = sheet.add(new Date(System.currentTimeMillis()+5555555),"a7", "m/d/yy h:mm");
        Logger.logInfo(a7.getFormattedStringVal());
        
        
        // Excel Divides the day into 100 units, so .25 is 9am, .5 is 12 noon, .75 is 9pm, and 00 is midnight
        try{
            sheet.add(new Float(2000.75),"a5"); // add a new cell, set date format
            CellHandle a5 = sheet.getCell("a5");
            a5.setFormatId(GMT_FORMAT);
            Logger.logInfo(sdf.format(DateConverter.getDateFromCell(a5)));
        }catch(Exception e){
        	Logger.logErr("setting date failed.",e);
        }
        
       
        try{
            // set today's date in cell A10
            Date dt = new Date(System.currentTimeMillis());
            Calendar gc = new java.util.GregorianCalendar();
            gc.setTime(dt);
            double dd = DateConverter.getXLSDateVal(gc);
        	CellHandle a10 = sheet.add(new Double(dd),"A10"); // add a new cell, set date format
            a10.setFormatId(GMT_FORMAT); // set date format on cell
            Logger.logInfo(sdf.format(DateConverter.getDateFromCell(a10)));
        }catch(Exception e){
        	Logger.logErr("setting date failed.",e);
        }
        testWrite(book);
    }

    public void testWrite(WorkBookHandle b){
        try{
      	    java.io.File f = new java.io.File(wd+"testAddOutput.xls");
            FileOutputStream fos = new FileOutputStream(f);
            BufferedOutputStream bbout = new BufferedOutputStream(fos);
            b.writeBytes(bbout);
            bbout.flush();
		    fos.close();
      	} catch (java.io.IOException e){Logger.logInfo("IOException in Tester.  "+e);}  
    }

}