package docs.samples.Images;

import com.extentech.toolkit.Logger;
import com.extentech.ExtenXLS.*;

import java.io.*;

/**##LICENSE##*/

/* Test the operation of image insert and extract

	@author John McMahon
	@version 1.0
*/
public class TestImages{
    
    // change to the folder containing the image files and spreadsheet templates
    String workingdir = "C:/ExtenXLS6/docs/samples/Images/";
	int DEBUGLEVEL = 0;
	WorkSheetHandle sheet = null;
	String sheetname = "Sheet1";
	String finpath = "";
	
	public static void main(String[] args) {
		TestImages ti = new TestImages("Test Images",0);
		ti.test();
		
	}
	
	public TestImages(String name, int lev){
		DEBUGLEVEL = lev;
	}
	
	/** read in an XLS file, output BiffRec vals, write it back to a new file
	*/
	public void test(){
		// working files
		String[] testfiles = {
			"testImages.xls","Sheet1",
		};
       
		for(int i = 0;i<testfiles.length;i++){
			finpath = testfiles[i];
			System.out.println("====================== TEST: " + String.valueOf(i) + " ======================");
			sheetname = testfiles[++i];
			System.out.println("=====================> " + finpath + ":" + sheetname);
			
			doit(finpath, sheetname);
		
			System.out.println("DONE");
		}       
	}
    
	void doit(String finpath, String sheetname){    
		System.out.println("Begin parsing: " + workingdir + finpath);
		WorkBookHandle tbo = new WorkBookHandle(workingdir + finpath);
		
		try{
			sheet = tbo.getWorkSheet(sheetname);
			// read images from sheet 1 -- .gif, .png, .jpg
			ImageHandle[] extracted = sheet.getImages();
			// extract and output images
			for(int t=0;t<extracted.length;t++) {
				System.out.println("Successfully extracted: " + workingdir + "testImageOut_" + extracted[t].getName()+"."+extracted[t].getType());
    			FileOutputStream outimg = new FileOutputStream(workingdir + extracted[t].getName()+"."+extracted[t].getType());
				extracted[t].write(outimg);
				outimg.flush();
				outimg.close();
			}
			
			tbo = new WorkBookHandle();
			sheet = tbo.getWorkSheet("Sheet1");
			CellHandle a1 = sheet.add("This is a new workbook with 3 images: a gif, a jpg, and a png", "A1");
			
			// get gif image input stream
			FileInputStream fin = new FileInputStream(workingdir + "testImages.gif");
			
			// add to sheet
			ImageHandle giffy = new ImageHandle(fin, sheet);
			
			// set picture size and location in sheet
			giffy.setCoords(100, 100, 400, 200);
			giffy.setName("giffy");
			sheet.insertImage(giffy);

			// add to sheet
			for(int x=0;x<100;x++) {
				fin = new FileInputStream(workingdir + "testImages.png");
				ImageHandle jpgy = new ImageHandle(fin, sheet);
				jpgy.setName("heart" + x);
				// set the random x/y coords of picture
				int ix = Math.round((float)((x * (Math.random()*10))));
				jpgy.setX(100 +  ix);
				ix = Math.round((float)((x * (Math.random()*10))));
				jpgy.setY(100 + ix);
				sheet.insertImage(jpgy);
			}
			// get png image input stream

			fin = new FileInputStream(workingdir + "testImages.jpg");
			
			// add to sheet
			ImageHandle pngy = new ImageHandle(fin, sheet);
			
			// set just the x/y coords of picture
			pngy.setX(10);
			pngy.setY(200);
			sheet.insertImage(pngy);
			
		
		}catch(Exception e){
			System.err.println("testImages failed: " + e.toString());
		}
		testWrite(tbo, workingdir + "testImagesOut.xls");
		WorkBookHandle newbook = new WorkBookHandle(workingdir + "testImagesOut.xls",0);
		System.out.println("Successfully read: " + newbook);
	}
	
    public void testWrite(WorkBookHandle b, String fout){
        try{
      	    java.io.File f = new java.io.File(fout);
            FileOutputStream fos = new FileOutputStream(f);
            BufferedOutputStream bbout = new BufferedOutputStream(fos);
            b.writeBytes(bbout);
            bbout.flush();
		    fos.close();
      	} catch (java.io.IOException e){Logger.logInfo("IOException in Tester.  "+e);}  
    }
	
}