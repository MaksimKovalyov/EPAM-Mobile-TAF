﻿package docs.samples.Hyperlinks;

import com.extentech.ExtenXLS.*;
import com.extentech.formats.XLS.*;
import com.extentech.toolkit.Logger;

import java.io.*;
import java.sql.Date;

/* Copyright 2002 Extentech Inc.
EXTENTECH SOFTWARE LICENSE AGREEMENT

All Java classes and other files contained in the com.extentech package are protected
by copyright and are the sole property of Extentech Inc.

This software may be used only by Extentech customers and may not be copied, sold, distributed
or used for any other purpose without the prior written consent of Extentech.  Those
interested in licensing components, servlets, and utility classes separately from the Luminet
Server product should contact Extentech Inc. at sales@extentech.com.

You agree that you will not reverse-engineer, or decompile the compiled files distributed with
this program with the exception of open-source servlets and other files with which source code
is included in the distribution.

To the maximum extent permitted by law, Extentech Inc. disclaims all warranties regarding
this software, expressed or implied, including but not limited to warranties of merchantability
and fitness for a particular purpose. In no event shall Extentech be liable for special,
consequential, incidental or indirect damages arising out of the use or inability
to use this software even if Extentech Inc. is aware of the possibility of such
damages or known defects.

This software is provided AS IS.
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.

By using this software, you are agreeing to all of the terms of this license.
****************************************************/


/**
      @author John McMahon -- Copyright &&copy;2006<a href = "http://www.extentech.com">Extentech Inc.</a>
      @version 4.1
 * @since 1.3

    This Class Demonstrates the basic functionality of Hyperlink handling in ExtenXLS.

 */
public class TestHyperlinks{

    public static void main(String[] args){
        TestHyperlinks t = new TestHyperlinks();
		t.testHyperlinks();
    }

    void testHyperlinks(){    
        WorkBookHandle tbo = new WorkBookHandle();
        String sheetname = "Sheet1";
        WorkSheetHandle sheet1 = null;
        try{
            sheet1 = tbo.getWorkSheet(sheetname);
        }catch (WorkSheetNotFoundException e){System.out.println("couldn't find worksheet" + e);}            
        
        try{
            
           tbo.copyWorkSheet(sheetname,"copy of "+sheetname);
        }catch(WorkSheetNotFoundException e){System.out.println(e);}

        String st4 = "G";
        
        try{
            // CellHandle salary3 = sheet1.getCell(st4);
            String ht="E3:E10";
            for(int t = 3; t<=10;t++){
                sheet1.add("ExtenXLS Home Page","E" + t);
                CellHandle link1 = sheet1.getCell("E"+t);
                sheet1.moveCell(link1,st4 + t);
                link1.setURL("http://www.extentech.com/estore/product_detail.jsp?product_group_id=1");
            }

        }catch(CellNotFoundException e){System.out.println(e);}
        catch(CellPositionConflictException r){System.out.println(r);} 
        testWrite(tbo);
    }
    public void testWrite(WorkBookHandle b){
        try{
      	    java.io.File f = new java.io.File("testHyperlinks.xls");
            FileOutputStream fos = new FileOutputStream(f);
            BufferedOutputStream bbout = new BufferedOutputStream(fos);
            b.writeBytes(bbout);
            bbout.flush();
		    fos.close();
      	} catch (java.io.IOException e){Logger.logInfo("IOException in Tester.  "+e);}  
    }
    
   
}