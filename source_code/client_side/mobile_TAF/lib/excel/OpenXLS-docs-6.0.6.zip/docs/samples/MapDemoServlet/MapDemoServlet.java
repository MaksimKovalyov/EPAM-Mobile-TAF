﻿package docs.samples.MapDemoServlet;

import java.io.BufferedOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.extentech.ExtenXLS.*;
import com.extentech.formats.XLS.CellNotFoundException;
import com.extentech.formats.XLS.CellTypeMismatchException;
import com.extentech.formats.XLS.WorkSheetNotFoundException;
import com.extentech.toolkit.Logger;


/* Copyright 2005 Extentech Inc.
EXTENTECH SOFTWARE LICENSE AGREEMENT

All Java classes and other files contained in the com.extentech package are protected
by copyright and are the sole property of Extentech Inc.

This software may be used only by Extentech customers and may not be copied, sold, distributed
or used for any other purpose without the prior written consent of Extentech.  Those
interested in licensing components, servlets, and utility classes separately from the Luminet
Server product should contact Extentech Inc. at sales@extentech.com.

You agree that you will not reverse-engineer, or decompile the compiled files distributed with
this program with the exception of open-source servlets and other files with which source code
is included in the distribution.

To the maximum extent permitted by law, Extentech Inc. disclaims all warranties regarding
this software, expressed or implied, including but not limited to warranties of merchantability
and fitness for a particular purpose. In no event shall Extentech be liable for special,
consequential, incidental or indirect damages arising out of the use or inability
to use this software even if Extentech Inc. is aware of the possibility of such
damages or known defects.

This software is provided AS IS.
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.

By using this software, you are agreeing to all of the terms of this license.
****************************************************/

/** A Sample Servlet demonstrating ExtenXLS usage in a Servlet application.

      @author John McMahon -- Copyright &&copy;2006<a href = "http://www.extentech.com">Extentech Inc.</a>
      @version 4.1
    @since 1.3
*/
public class MapDemoServlet extends javax.servlet.http.HttpServlet{

    WorkBookHandle book = null;
    String finpath = "";
    String homepath = "";
    
	public void init(){
		homepath = "/home/webapp/";
		finpath = "/mytemplate.xls";
		int debuglev = 0;
		book = new WorkBookHandle(homepath+ finpath, debuglev);
	}
   
    public void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException
    {
      	try{
      	    // get handles to the cells
      	    WorkSheetHandle sheet1 = book.getWorkSheet("Sheet1");
      	    CellHandle mystate = sheet1.getCell("A4");
      	    CellHandle mysales = sheet1.getCell("B4");
      	    
      	    // set the cell values
            if(req.getParameter("state")!=null)
            try{
                mystate.setVal(req.getParameter("state"));
            }catch(CellTypeMismatchException e){System.out.println(e);}
            String salesval = "0";
            if(req.getParameter("sales")!=null)salesval = req.getParameter("sales");
          	    
          	try{
          	    mysales.setVal(Float.parseFloat(salesval));
            }catch(CellTypeMismatchException e){System.out.println(e);}
      	    
      	    
        }catch (CellNotFoundException e){log("couldn't find cell" + e);
        }catch(WorkSheetNotFoundException e){System.out.println(e);}
        res.setStatus(HttpServletResponse.SC_OK);
	    log( "XLS Map Demo called" );
	    res.setContentType("application/vnd.ms-excel");        
      	if(false){ 	
      	    String foutput = "mapdemoout.xls";
      	    testWrite(book,foutput);
	    }
		ServletOutputStream out = res.getOutputStream();
		book.writeBytes(out);
        out.flush();
        out.close();
    }

    public void testWrite(WorkBookHandle b, String fout){
        try{
      	    java.io.File f = new java.io.File(fout);
            FileOutputStream fos = new FileOutputStream(f);
            BufferedOutputStream bbout = new BufferedOutputStream(fos);
            b.writeBytes(bbout);
            bbout.flush();
		    fos.close();
      	} catch (java.io.IOException e){Logger.logInfo("IOException in Tester.  "+e);}  
    } 
}
