package docs.samples.WebWorkBook;

import java.io.*;
import java.security.*;
import org.custommonkey.xmlunit.*;
import junit.framework.TestCase;
import com.extentech.ExtenXLS.web.*;
import com.extentech.ExtenXLS.CellHandle;
import com.extentech.ExtenXLS.ExtenXLS;
import com.extentech.ExtenXLS.WorkBookHandle;
import com.extentech.ExtenXLS.WorkBook;
import com.extentech.comm.*;
import com.extentech.security.*;
import com.extentech.toolkit.Logger;
import com.extentech.toolkit.StringTool;



/** Test the functionality of the Web-Enabled WorkBook including loading/storing WorkBooks to Sheetster.com
 *  as well as revision handling.
 * 
 * For detailed instructions on using the versioning functions please visit:
 * 
 * http://www.extentech.com/docs_detail.jsp?meme_id=713&page_meme_type=21
 * 
 * @author John McMahon - Copyright &copy; 2006 <a href="http://www.extentech.com">Extentech Inc.</a>
 * @version 
 * @since 
 * @see
 */
public class TestWebWorkBook extends TestCase  {
	String workingdir= "";
	String outputdir= "";
	
	public TestWebWorkBook(String name){
		super(name);
	 }
	public TestWebWorkBook() {
//		System.out.println("DONE");
	}
	
	public void setWorkingDirectory(String wdir) { this.workingdir= StringTool.qualifyFilePath(wdir); }
	public void setOutputDirectory(String odir) { this.outputdir= StringTool.qualifyFilePath(odir); }
	
    public void testVersioningFiles(String[][] testFiles, String outputdir) {
		System.out.println("======================> testWebWorkBook ======================");
		
		try {
			WebWorkBook wwb= null;			
			if (outputdir==null) outputdir= workingdir;
			for (int i= 0; i < testFiles.length; i++) {
		    	// create lockdowns
		    	// create XML from XLS				
			    String f0= testFiles[i][0].toUpperCase();
			    String f1= testFiles[i][1].toUpperCase();
			    String f0Lockdown= f0+".lockdown";
			    System.out.println("Version Test: " + f1 + " to " + f0);
			    if (f0.endsWith(".XLS"))	{
					// create lockdown file
			    	WorkBookHandle bk= new WorkBookHandle(workingdir+f0);

					// Create XML file from WorkBookHandle
					byte[] bbuf = ExtenXLS.getXML(bk).getBytes();
					System.out.print(" Converting " + f0 + " to XML ");
	    	    	f0= f0.substring(0, f0.length()-4) + ".XML";
	    	    	System.out.println(f0);
					ExtenXLS.writeBytesToFile(outputdir+f0, bbuf);
					f0= outputdir+f0;
			    } else {
			    	System.out.println(" Recording comparison file " + f0Lockdown);
			    	f0= workingdir+f0;
			    }
			    if (f1.endsWith(".XLS")) {
			    	// create XML file
			    	WorkBookHandle bk= new WorkBookHandle(workingdir+f1);
					byte[] bbuf = ExtenXLS.getXML(bk).getBytes();
					System.out.print(" Converting " + f1 + " to XML ");
	    	    	f1= f1.substring(0, f1.length()-4) + ".XML";
	    	    	System.out.println(f1);
					ExtenXLS.writeBytesToFile(outputdir+f1, bbuf);
			    }
			    
			    // create the new WebWorkBook
			    wwb= new WebWorkBook(f0, workingdir+f1, outputdir, false);
			    // test committing changes - changed file = f1
			    wwb.commit();

			}		    		    
    	} catch (Exception e) {
    		System.err.println("ERROR: testWebWorkBook: " + e.getMessage());
    	}
    }	
    
    
    /** Test Sessions...
     * 
     * 
     * @param inExpected
     * @param inActual
     * @param name
     */
    public void testSessions(int meme_id){
    	
    	String[] userlist = {"username@company.com"};
    	String[] passlist = {"somepassword"};
    		
    	for(int t=0;t<userlist.length;t++){
			try {
				WebWorkBook wwb= null;
				
				Principal usr = (Principal)this.getLoggedInUser(userlist[t],passlist[t]);
				if (meme_id==-1) { 
					// flag to input new workbook					
					meme_id = 563; // a public workbook for now ... "Moving Checklist..." has hyperlinks and values, no big deal.
	    			WorkBook bk = new WorkBookHandle(workingdir + "MovingChecklist.xls");
		    		MemeWorkBook mwb= new MemeWorkBook();
		    		mwb.saveBook(bk, meme_id);
				}		    
				
				wwb= new WebWorkBook(/*WebWorkBook.DEFAULT_URL, */meme_id, (User)usr);
				
				// use the workbook built-in messaging session to alert other
				// concurrent users
				//wwb.getMessageManager().se.sendToAll("Hello from: " + userlist[t]);
				
				System.out.println(wwb);// the basics!
				
				WorkBook bookOriginal= (WorkBook) wwb;
				
				// now update the original 
				CellHandle ch= bookOriginal.getWorkSheet(0).add("test" + t, "A1");
				
	    		// commit the changes
	    		wwb.commit();		

			    // now get the latest from the db 
	    		WorkBook bookReverted= wwb.revert();
	    			    		
	    		// input original workbook back
	    		wwb.saveBook(bookReverted, meme_id);
			}catch(Exception e){
				System.err.println("ERROR: TestWebWorkBook Failed: " + e);
			}
    	}
    }

    /**
     * 
     * @param inExpected
     * @param inActual
     * @param name
     */
    protected void checkXmlEqual(Reader inExpected, Reader inActual, String name) {
        DetailedDiff diff = null;
        
        try {
            diff = new DetailedDiff(new Diff(inExpected, inActual));
        } catch (Exception e) {
            //System.out.println(" " + name + " has differences");
            System.out.println(" " + e.toString());
	        return;
        }

        if (!diff.similar()) {
	        //System.out.println(" " + name + " has differences");
	        System.out.println(" " + diff.toString());
        }
    }


    static final String ENCODING= com.extentech.formats.XLS.WorkBook.DEFAULTENCODING;


    
    /**
     * order return cellHandle array  via sheet order
     * @param wb	workbook to obtain cells from
     * @return		ordered CellHandle[]
     */
	public CellHandle[] getOrderedCells(WorkBookHandle wb) {
		int n= wb.getWorkBook().getNumWorkSheets();
		CellHandle[] cells= new CellHandle[0];
		for (int i= 0; i < n; i++) {
			try {
				CellHandle[] tmp= wb.getWorkSheet(i).getCells();			
				CellHandle[] tmp2= new CellHandle[cells.length+tmp.length];
				System.arraycopy(cells, 0, tmp2, 0, cells.length);
				System.arraycopy(tmp, 0, tmp2, cells.length, tmp.length);
				cells= new CellHandle[tmp2.length];
				System.arraycopy(tmp2, 0, cells, 0, tmp2.length);
				
			}
			catch (Exception e) { }			
		}		
		return cells;			
	}
	

	/** compares the contents of your stringbuffer with the contents of 
	 *  a lockdown file.
	 * 
	 * 
	 * @param lockfile
	 * @param buff
	 */
	public void assertAgainstLockdown(String lockfile, StringBuffer buff) {
		// compare the output with a static version of the file
	    String lockstr = "lockdown file not initialized";
	    try{
	        FileInputStream fis = new FileInputStream(new File(lockfile));
	        byte[] bar = new byte[fis.available()]; 
	        fis.read(bar);
	        lockstr = new String(bar, ENCODING); 
	    }catch(Exception e) {
	        fail("ERROR: problem reading the lockdown file for: " + lockfile);
	    }
	    String outstr = buff.toString();
	    //System.out.println(outstr);
	    assertEquals(lockstr,outstr);
	}

    public User getLoggedInUser(String name, String pass) {
	    String dbsettings = "org.gjt.mm.mysql.Driver,jdbc:mysql://yourdb.com";
        String[] settings = StringTool.getTokensUsingDelim(dbsettings, ",");
        
        UserFactory factory = new UserFactory(settings);
        try {
            factory.init();
        }catch(Exception e) {
            fail(e.toString());
        }
        
        // initialize a user object from database using login credentials
        User thisUser = factory.getUser();
        thisUser.setUserName(name);
        
        try{
            thisUser.login(pass);
        }catch (Exception e) {
            System.err.println(e);
        }
        return thisUser;
	}	
    
	private static void setOutput(String outputDir) {
		try{
		    java.io.File logfile = new java.io.File(outputDir+"testWebWorkBook.log");        
			BufferedOutputStream sysout = new BufferedOutputStream( new FileOutputStream(logfile));
			System.setOut(new PrintStream(sysout));
		    java.io.File errfile = new java.io.File(outputDir+"testWebWorkBookERR.log");        
			BufferedOutputStream syserr = new BufferedOutputStream( new FileOutputStream(errfile));
			System.setErr(new PrintStream(syserr));
		}catch (IOException e){System.out.println("IOE: " + e);}    	
    }
    
	public static void main(String[] args) {
		int id= -1;
		final String filePairDelim=";";
		final String fileDelim=",";
		boolean bFromWeb= true;
		boolean bInit= false;
		String workingdir= "c:/ExtenXLS6/docs/samples/WebWorkBook/";
		String outputdir= null;
		String files= "TestXMLDiff1.xml" + fileDelim+ "TestXMLDiff2.xml" + filePairDelim +  
					  "TestXMLLatest.xml" + fileDelim+ "TestXMLCurrent.xml" + filePairDelim +  
					  "InvoiceTemplate.xls_out.xml" + fileDelim+ "InvoiceTemplateREFINED.xls_out.xml" + filePairDelim + 
					  "InvoiceReport.xls" + fileDelim+ "InvoiceReportAltered.xls";	 
	    String[][] testFiles= null;
				
		
		if (args.length > 0) {		
			for (int i= 0; i < args.length; i++) {
				if (args[i].equals("-w")) {
					if (i < args.length - 1) workingdir= args[++i];
				} else if (args[i].equals("-f")) {
					if (i < args.length - 1) files= args[++i];
					bFromWeb= false;
				} else if (args[i].equals("-o")) {
					if (i < args.length - 1) outputdir= args[++i];
				} else if (args[i].equals("-i")) {
					try {
						id= Integer.parseInt(args[++i]);
					} catch (Exception e) { }
				}
			}
		}
		workingdir= StringTool.qualifyFilePath(workingdir);
		if (outputdir!=null) {
			outputdir= StringTool.qualifyFilePath(outputdir);
			setOutput(outputdir);
		}
	    TestWebWorkBook testw = new TestWebWorkBook();
	    testw.setWorkingDirectory(workingdir);
	    if (outputdir==null) outputdir= workingdir + "Versioning";
    	testw.setOutputDirectory(outputdir);
	    if (bFromWeb) {
	    	testw.testSessions(id);
	    } else {
	    	testw.setOutputDirectory(outputdir);
	    	String[] filePairs=StringTool.getTokensUsingDelim(files,filePairDelim);
	    	testFiles= new String[filePairs.length][]; 
	    	for (int i= 0; i < filePairs.length; i++) {
	    		testFiles[i]= StringTool.getTokensUsingDelim(filePairs[i], fileDelim);	    		
	    	}
	    	testw.testVersioningFiles(testFiles, outputdir);
	    }
	}
	
    /** Demonstrates concurrent WorkBook sessions
     *  ------------------------------------------------------------
     * 
     * @author admin :: [ Nov 29, 2007 ] :: Copyright &copy;2006 <a href = "http://www.extentech.com">Extentech Inc.</a>
     *
     * @

	public void testMessaging() {
		// test the message send receive
		
		MessageClient messenger1 = new MessageClient("Joe");
		MessageClient messenger2 = new MessageClient("Salish");
		
		Messaging session = new Messaging();
		session.registerClient(messenger1);
		session.registerClient(messenger2);
		
		messenger1.sendMessage("Hello World!");
		messenger2.sendMessage("Good day to you Sir!");
		
		Logger.logInfo("Messaging has: "+ session.getClientCount() + " listening clients:");
		String[] clnm = session.listClientNames();
		for(int r=0;r<clnm.length;r++){
			Logger.logInfo("  - " + clnm[r]);
		}
	}     */
}
