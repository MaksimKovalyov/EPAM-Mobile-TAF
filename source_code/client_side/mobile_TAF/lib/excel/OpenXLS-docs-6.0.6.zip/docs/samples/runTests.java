package docs.samples;

import docs.samples.AddingCells.*;
import docs.samples.CellBinder.*;
import docs.samples.Charts.*;
import docs.samples.Dates.*;
import docs.samples.Formats.*;
import docs.samples.Formulas.*;
import docs.samples.Hyperlinks.*;
import docs.samples.MapDemoServlet.*;
import docs.samples.NamedRanges.*;
import docs.samples.SalaryServlet.*;
import docs.samples.TemplateModifications.*;
import docs.samples.XSLTransformations.*;

/** Convenient program to run ExtenXLS tests
 * 
      @author John McMahon -- Copyright &copy;2006 <a href = "http://www.extentech.com">Extentech Inc.</a>
      @version 4.1
*/
public class runTests{
	
	public static void main(String[] args){
		
		System.out.println("Running: Transform");
		Transform tfm = new Transform();
		tfm.transform();
		
		System.out.println("Running: TestCellAdding");
		TestCellAdding tca = new TestCellAdding();
		String[] none = {""};
		tca.main(none);
		
		System.out.println("Running: CellBinder");
		TestCellBinder tcb = new TestCellBinder();
		tcb.testRunReport();
		
		
	}

	
}