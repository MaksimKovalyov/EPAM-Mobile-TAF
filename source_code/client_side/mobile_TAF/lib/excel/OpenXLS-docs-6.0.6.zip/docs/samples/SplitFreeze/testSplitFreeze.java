package docs.samples.SplitFreeze;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import junit.framework.Assert;
import com.extentech.ExtenXLS.WorkBookHandle;
import com.extentech.ExtenXLS.WorkSheetHandle;
import com.extentech.toolkit.Logger;

/** Tests the freeze pane and split-pane functionality of the WorkSheetHandle
 *  ------------------------------------------------------------
 * 
 * @author admin :: [ Nov 29, 2007 ] :: Copyright &copy;2007 <a href = "http://www.extentech.com">Extentech Inc.</a>
 *
 * @
 */
public class testSplitFreeze{
	public static final String EXCEL_DIRECTORY = "C:/ExtenXLS6/docs/samples/SplitFreeze/";

	WorkBookHandle workbook;

	public static void main(String[] args) {
	    testSplitFreeze test = new testSplitFreeze();
	    try {
	        test.setUp();
			test.tesSplitCols();
			test.tesSplitRows();
			test.testFreezePanes();			
	    }catch(Exception ex) {
	        Logger.logErr("testSplitFreeze failed", ex);
	    }
	}
	
	protected void setUp() throws Exception {
		workbook = new WorkBookHandle();
		workbook.setDupeStringMode(WorkBookHandle.SHAREDUPES);
		workbook.setStringEncodingMode(WorkBookHandle.STRING_ENCODING_COMPRESSED);
	}
	
	/** splits cols into panes
	 *  ------------------------------------------------------------
	 * 
	 * @author admin [ Nov 29, 2007 ]
	 *
	 */
	protected void tesSplitCols() {
		try {
			WorkSheetHandle sheet= workbook.getWorkSheet(0);
			sheet.splitCol(5, 5000); // split at col 5 (F), set divider at 1000 col units
		} catch (Exception e) {
			System.out.println("Error setting Split panes: " + e.getMessage());
		}
		writeFile(workbook, "testSplitPanesCol.xls");	
	}
	
	/** splits rows into panes
	 *  ------------------------------------------------------------
	 * 
	 * @author admin [ Nov 29, 2007 ]
	 *
	 */
	protected void tesSplitRows() {
		try {
			WorkSheetHandle sheet= workbook.getWorkSheet(0);
			sheet.splitRow(10, 5000); // split at row 10, set divider at 5000 twips
		} catch (Exception e) {
			System.out.println("Error setting Split panes: " + e.getMessage());
		}
		writeFile(workbook,"testSplitPanesRow.xls");		
	}
	
	/** freezes panes
	 *  ------------------------------------------------------------
	 * 
	 * @author admin [ Nov 29, 2007 ]
	 *
	 */
	protected void testFreezePanes() {
		String fileName = "testFreezePanes.xls";
		try {
			WorkSheetHandle sheet= workbook.getWorkSheet(0);
			// try freezing
			sheet.freezeRow(9);
			sheet.freezeCol(17);
		} catch (Exception e) {
			System.out.println("Error setting Freeze panes: " + e.getMessage());
		}
		writeFile(workbook, fileName);		
	}

	/** write the file to disk
	 *  ------------------------------------------------------------
	 * 
	 * @author admin [ Nov 29, 2007 ]
	 * @param workBookHandle
	 * @param excelFileName
	 */
	private static void writeFile(WorkBookHandle workBookHandle,
			String excelFileName) {
		try {
			File outputFile = new File(EXCEL_DIRECTORY + excelFileName);
			FileOutputStream fileOutputStream = new FileOutputStream(outputFile);
			BufferedOutputStream bufferedOutputStream = new BufferedOutputStream(fileOutputStream);
			
			workBookHandle.writeBytes(bufferedOutputStream);
			
			bufferedOutputStream.flush();
			fileOutputStream.close();
		} catch (java.io.IOException e) {
			Assert.fail("Exception thrown when trying to write the file: " + e);
		}
	}

}
