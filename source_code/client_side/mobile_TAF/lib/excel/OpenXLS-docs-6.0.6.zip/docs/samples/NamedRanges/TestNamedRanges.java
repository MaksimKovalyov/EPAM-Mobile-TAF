package docs.samples.NamedRanges;

import com.extentech.ExtenXLS.*;
import com.extentech.formats.XLS.*;
import com.extentech.toolkit.Logger;

import java.io.*;

/* Copyright 2003 Extentech Inc.
EXTENTECH SOFTWARE LICENSE AGREEMENT

All Java classes and other files contained in the com.extentech package are protected
by copyright and are the sole property of Extentech Inc.

This software may be used only by Extentech customers and may not be copied, sold, distributed
or used for any other purpose without the prior written consent of Extentech.  Those
interested in licensing components, servlets, and utility classes separately from the Luminet
Server product should contact Extentech Inc. at sales@extentech.com.

You agree that you will not reverse-engineer, or decompile the compiled files distributed with
this program with the exception of open-source servlets and other files with which source code
is included in the distribution.

To the maximum extent permitted by law, Extentech Inc. disclaims all warranties regarding
this software, expressed or implied, including but not limited to warranties of merchantability
and fitness for a particular purpose. In no event shall Extentech be liable for special,
consequential, incidental or indirect damages arising out of the use or inability
to use this software even if Extentech Inc. is aware of the possibility of such
damages or known defects.

This software is provided AS IS.
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.

By using this software, you are agreeing to all of the terms of this license.
****************************************************/


/**
      @author John McMahon -- Copyright &copy;2006 <a href = "http://www.extentech.com">Extentech Inc.</a>
      @version 4.1

    This Class Demonstrates the basic functionality of of ExtenXLS.

 */
public class TestNamedRanges{

    public static void main(String[] args){
        testnames t = new testnames();
		String s = "Test Successful.";
		if(args.length>0)s = args[0];
		t.testit(s);
    }
}

/** Test the handling of and modification of Named Ranges
*/
class testnames{

    public void testit(String argstr){
        WorkBookHandle tbo = new WorkBookHandle("testNames.xls");
        try{
            WorkSheetHandle sheet1 = tbo.getWorkSheet("Sheet1");

            String ht="E3:E10";
            for(int t = 3; t<=10;t++){
                try{
                    sheet1.add(new Float(t*67.5),"E" + t);
                }catch(Exception e){;}
            }
           
           // this will throw a CellNotFoundException if the name is not found.
            NameHandle nand = tbo.getNamedRange("nametest4");
            CellHandle[] ch = nand.getCells();
            for(int x = 0;x<ch.length;x++){
                ch[x].setVal(123 * x);
                ch[x].setFontColor(FormatHandle.PaleBlue);
            }
            System.out.println(nand.getName());
            
            NameHandle nand2 = tbo.getNamedRange("nametest7");
            CellHandle[] ch1 = nand2.getCells();
            for(int x = 0;x<ch1.length;x++){
                System.out.println(ch1[x].getWorkSheetName() +":"+ ch1[x].getCellAddress() +":"+ ch1[x].getVal());
            }
            nand2.setName("IMPORTANT");
            System.out.println(nand2.getName());            
            nand2.setLocation("A1:B15");     
            
            NameHandle nand3 = tbo.getNamedRange("nametest10");
            CellHandle[] ch2 = nand3.getCells();
            for(int x = 0;x<ch2.length;x++){
                System.out.println(ch2[x].getWorkSheetName() +":"+ ch2[x].getCellAddress() +":"+ ch2[x].getVal());
            }
            System.out.println(nand3.getName());        
            nand3.setName("URGENTCELLS");
            nand3.setLocation("D15");    

            
            
            
			// Create new NameHandle from a CellRange
			CellRange range = new CellRange( "Sheet1!D8:D13", tbo);
			NameHandle newname = new NameHandle("NEWNAME",range);	
			try{
				CellRange[] ranges = newname.getCellRanges();
				for(int t=0;t<ranges.length;t++){
					System.out.println("Got new range:" + ranges[t].toString());
				}
			}catch(Exception e){
				System.err.println("Problem creating new Named Range:" + newname.toString());
			}
        }catch(CellNotFoundException e){System.out.println(e);}
        catch(WorkSheetNotFoundException e){System.out.println(e);}
        testWrite(tbo);
    }

    public void testWrite(WorkBookHandle b){
        try{
      	    java.io.File f = new java.io.File("testNamesOutput.xls");
            FileOutputStream fos = new FileOutputStream(f);
            BufferedOutputStream bbout = new BufferedOutputStream(fos);
            b.writeBytes(bbout);
            bbout.flush();
		    fos.close();
      	} catch (java.io.IOException e){Logger.logInfo("IOException in Tester.  "+e);}  
    }

}