/** ------------------------------------------------------------
 * CopySheets.java
 *
 * ##LICENSE##
 *
 * @author John [ Nov 27, 2006 ]
 * ------------------------------------------------------------
 */
package docs.samples.CopySheets;

import java.awt.Font;
import java.io.BufferedOutputStream;
import java.io.FileOutputStream;
import java.sql.Date;
import com.extentech.toolkit.*;
import com.extentech.ExtenXLS.*;

/** ------------------------------------------------------------
 *  This test demonstrates how to read in values from a source workbook and split into
 *  multiple output worksheets.
 * 
 * 
 * @author John :: [ Nov 27, 2006 ] :: Copyright &copy;2006 <a href = "http://www.extentech.com">Extentech Inc.</a>
 *
 */
public class CopySheets {

	static String wd = "C:/eclipse/workspace/ExtenXLS_6/docs/samples/CopySheets/";
	
	/** ------------------------------------------------------------
	 * 
	 * @author John [ Nov 27, 2006 ]
	 * @param args
	 */
	public static void main(String[] args) {
		Logger.logInfo("ExtenXLS Version " + WorkBookHandle.getVersion());
		Logger.logInfo("---- Testing Copy Sheet Functionality ---- " );
		CopySheets cx = new CopySheets();
		try{
			cx.doit();
		}catch(Exception ex) {
			Logger.logErr("ERROR: CopySheets Failed: " + ex.toString());
		}
		Logger.logInfo("---- Done with Copy Sheet ---- "  );
		

	}

	
	/** test entry-point
	 *  ------------------------------------------------------------
	 * 
	 * @author John [ Nov 27, 2006 ]
	 * @throws Exception
	 */
	public void doit() throws Exception {
		
		// some big input file with a lot of sheets to copy
		WorkBookHandle biginput = new WorkBookHandle(wd+"o_1.xls");
		
		
		// loop through the input sheets and copy contents
		WorkSheetHandle[] shts = biginput.getWorkSheets();
		for( int i=0;i < shts.length;i++){
			long begin = System.currentTimeMillis();
			Logger.logInfo("Processing sheet: " + shts[i]);

			//			 create new workbook
			WorkBookHandle newbook = new WorkBookHandle();
			
			// get the sheet to copy
		    WorkSheetHandle sheet = biginput.getWorkSheet(i);
		    
		    // rename the target sheet
		    WorkSheetHandle newsheet = newbook.getWorkSheet("Sheet1"); 
		    newsheet.setSheetName(shts[i].getSheetName());
		    
		    
		    // set 2 important performance settings for String handling
		    newbook.setDupeStringMode(WorkBookHandle.SHAREDUPES);
		    newbook.setStringEncodingMode(WorkBookHandle.STRING_ENCODING_COMPRESSED);
		    
		    // iterate the source sheet rows and copy values and formatting
		    // to new sheet
		    RowHandle[] rx = sheet.getRows();
		    int sz = rx.length;
		    
		    //newsheet.setShowGridlines(false);
		    
			for( int x=0;x < sz;x++){
		        CellHandle[] cx = rx[x].getCells();
				for( int t=0;t < cx.length;t++){
					
		            // copy cell values
		            CellHandle newcell = newsheet.add(cx[t].getVal(), cx[t].getCellAddress());
		            
		            // copy row height
		            int rz = cx[t].getRow().getHeight();
		            newcell.getRow().setHeight(rz);
		            //System.out.print("rw: " + rz);
		            
		            // copy col width, first row only
		            if(x ==0) {
			            ColHandle cw = newcell.getCol();
			            ColHandle oldcw = cx[t].getCol();
			            
			           //Logger.logInfo("old: " + oldcw.getColFirst() +"|"+ oldcw.getColLast() + " wd: " + cx[t] + "-"+ oldcw.getWidth() + " collapsed?"+ oldcw.isCollapsed() + " hidden?"+ oldcw.isHidden());

			            cw.setHidden(oldcw.isHidden());
			            cw.setOutlineLevel(oldcw.getOutlineLevel());
			            
			            cw.setWidth(oldcw.getWidth());
		            	//Logger.logInfo("old: " + cw.getColFirst() +"|"+ cw.getColLast() + " wd: " + cx[t] + "-"+ cw.getWidth() + " collapsed?"+ cw.isCollapsed() + " hidden?"+ cw.isHidden());

		            }
		            
		            // copy merged ranges
		            CellRange rng = cx[t].getMergedCellRange();
		            if(rng != null) {
		            	rng = new CellRange(rng.getRange(), newcell.getWorkBook());
		            	rng.addCellToRange(newcell);
		            	rng.mergeCells(false);
		            }
		            
//		            copy cell formatting
		            FormatHandle newfmt = new FormatHandle();
		            // newcell.getFormatHandle();
		            FormatHandle oldfmt = cx[t].getFormatHandle();
		            try {			    
		            	
			            int ftyp = Font.PLAIN;
			            if(oldfmt.getIsBold())ftyp = Font.BOLD;
			            newfmt.setFont(oldfmt.getFontName(),ftyp,oldfmt.getFontHeightInPoints());
			            
			            newfmt.setItalic(oldfmt.getItalic());
			            
			            newfmt.setFontHeight(oldfmt.getFontHeight());
			            newfmt.setFontName(oldfmt.getFontName());
			            newfmt.setFontWeight(oldfmt.getFontWeight());
			            newfmt.setFontColor(oldfmt.getFontColor());	
			            newfmt.setCellRotation(oldfmt.getCellRotation());
			            newfmt.setFormatPattern(oldfmt.getFormatPattern());
			            newfmt.setCellBackgroundColor(oldfmt.getCellBackgroundColor());
			            newfmt.setBackgroundColor(oldfmt.getBackgroundColor());
			            newfmt.setForegroundColor(oldfmt.getForegroundColor());
			            newfmt.setHorizontalAlignment(oldfmt.getHorizontalAlignment());
			            newfmt.setVerticalAlignment(oldfmt.getVerticalAlignment());
			            newfmt.setWrapText(oldfmt.getWrapText());
			            
			            newfmt.setTopBorderLineStyle(	(short)oldfmt.getTopBorderLineStyle());
			            newfmt.setRightBorderLineStyle(	(short)oldfmt.getRightBorderLineStyle());
			            newfmt.setBottomBorderLineStyle((short)oldfmt.getBottomBorderLineStyle());
			            newfmt.setLeftBorderLineStyle(	(short)oldfmt.getLeftBorderLineStyle());
		            
			            newfmt.setWorkBook(newbook.getWorkBook());
			            newfmt = newfmt.pack(); // dedupe the Format Cache to decrease file size and avoid "too many fonts" error in Excel
			            newfmt.addCell(newcell);
			            
		          }catch(Exception e) {
		        	  System.err.println("WARNING: CopySheets Error: " + e.toString());//
		        	  
		          }			            
		        }
			}
			//Logger.logInfo(newbook.getStats());
			String bknm = "output_"+i+".xls";
			//Logger.logInfo("Writing book: " + bknm);
			testWrite(newbook, wd + bknm);
			long end = System.currentTimeMillis();
			Logger.logInfo("completed in: " + ((end-begin)) + " milliseconds");
		}
	}


    public void testWrite(WorkBookHandle b, String fout){
        try{
      	    java.io.File f = new java.io.File(fout);
            FileOutputStream fos = new FileOutputStream(f);
            BufferedOutputStream bbout = new BufferedOutputStream(fos);
            b.writeBytes(bbout);
            bbout.flush();
		    fos.close();
      	} catch (java.io.IOException e){Logger.logInfo("IOException in Tester.  "+e);}  
    }
	
}
