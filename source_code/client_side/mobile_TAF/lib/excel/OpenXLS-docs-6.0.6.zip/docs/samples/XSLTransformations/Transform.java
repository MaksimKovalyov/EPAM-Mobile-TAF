package docs.samples.XSLTransformations;

import java.io.*;

import com.extentech.ExtenXLS.*;
import org.jdom.Document;
import org.jdom.output.XMLOutputter;


/** Demonstrate the operation of XML -> XSL -> * tranformations.

	Requires JDOM package from www.jdom.org

      @author John McMahon -- Copyright &copy;2006 <a href = "http://www.extentech.com">Extentech Inc.</a>
      @version 4.1
*/
public class Transform
{
    
    private WorkBookHandle book;
    private String finpath = "", xslfile = "", workingdir = "C:/ExtenXLS6/docs/samples/XSLTransformations/";
    
	/** read in an XLS file transform it and output the new file
	*/
	public void transform(){
        
		// source xls file and xsl file
		String[] testfiles = {
			 "List Send Report Chart.xls","excel_2_html.xsl",
		};
       
		for(int i = 0;i<testfiles.length;i++){
			if(false){
				java.io.File logfile = new java.io.File("extenxls" + i +".log");        
				try{
					BufferedOutputStream sysout = new BufferedOutputStream( new FileOutputStream(logfile));
					System.setOut(new PrintStream(sysout));
				}catch (IOException e){System.out.println("IOE: " + e);}
			}
			finpath = testfiles[i];
			System.out.println("====================== TEST Transform: " + String.valueOf(i) + " ======================");
			xslfile = testfiles[++i];
			System.out.println("=====================> " + finpath + ":" + xslfile);
			doit(finpath, xslfile);
			this.testWrite(book,finpath+".out");
			System.out.println("TEST Transform DONE");
		}
		
        
	}

    void doit(String xlsfile, String xslfile){
		book = new WorkBookHandle(workingdir + xlsfile);
		// get the XML content

		// write the workbook XML to a file
		byte[] bbuf = ExtenXLS.getXML(book).getBytes();
		ExtenXLS.writeBytesToFile(workingdir + xlsfile + "_xml", bbuf);
		
		String htmlContent = null;
		
		// get the HTML output
		try{
			Document doc = ExtenXLS.transform(workingdir + xslfile,book);
			this.writeFile(doc,book.getName()+ "Tranformation_output_.html");
		}catch(Exception e){
			System.out.println("ERROR transforming document: " + e);
		}
		
		// write to file
		System.out.println(htmlContent);
		

	}
	
	/** output the DOM to file
	*/
	private boolean writeFile(Document d, String xp){
		try{
			FileOutputStream f = new FileOutputStream(new File(xp));
			XMLOutputter xout = new XMLOutputter();
			xout.getFormat().setIndent("  "); // use two space indent
			xout.getFormat().setLineSeparator("\r\n");
			xout.output(d, f);
		}catch(Exception e){
			System.out.println("Error Writing XML DataObject to file: " + e);
			return false;
		} 
		return true;
	}
    
 
	public void testWrite(WorkBookHandle b, String nm){
		try{
      	    java.io.File f = new java.io.File(nm);
            FileOutputStream fos = new FileOutputStream(f);
            BufferedOutputStream bbout = new BufferedOutputStream(fos);
            b.writeBytes(bbout);
            bbout.flush();
            bbout.close();
            fos.flush();
		    fos.close();
		    System.gc();
		} catch (java.io.IOException e){System.out.println("IOException in Tester.  "+e);}  
	}   
    
    
}