package docs.samples.Formats;

import java.io.*;
import java.io.File;

import com.extentech.ExtenXLS.*;

/** Demonstration of using Numeric Format Patterns
 * ------------------------------------------------------------
 * 
 * @author John McMahon :: [ Oct 10, 2007 ] :: Copyright &copy;2006 <a href = "http://www.extentech.com">Extentech Inc.</a>
 *
 * @see FormatHandle
 */
public class testFormatPatterns {

	/**
	 * 
	 */
	public testFormatPatterns() {
		super();
	}

	public static void main(String[] args) {
	    String wd = "C:/ExtenXLS_6/docs/samples/formats/";
		try {
		    
		    WorkBookHandle bookx = new WorkBookHandle(wd + "testFormatPatterns.xls");
		    
		    CellHandle cx[] = bookx.getCells();
		    for(int t=0;t<cx.length;t++) {
		        System.out.println(cx[t].getCellAddress() + ":" +cx[t].getFormatPattern());
		        
		    }
			
		    
		    
		    WorkBookHandle book = new WorkBookHandle();
			WorkSheetHandle sheet = book.getWorkSheet("Sheet1");
			for (int i = 0; i < 12; i++) {
				sheet.add(new Double(1.23456), "A" + (i+1));
			}
			sheet.getCell("A1").getFormatHandle().setFormatPattern("#,##0");
			sheet.getCell("A2").getFormatHandle().setFormatPattern("#,##0.0");
			sheet.getCell("A3").getFormatHandle().setFormatPattern("#,##0.00");
			sheet.getCell("A4").getFormatHandle().setFormatPattern("#,##0.000");
			sheet.getCell("A5").getFormatHandle().setFormatPattern("#,##0.0000");
			sheet.getCell("A6").getFormatHandle().setFormatPattern("#,##0.00000");
			
			sheet.getCell("A7").getFormatHandle().setFormatPattern( "0%");
			sheet.getCell("A8").getFormatHandle().setFormatPattern( "0.0%");
			sheet.getCell("A9").getFormatHandle().setFormatPattern( "0.00%");
			sheet.getCell("A10").getFormatHandle().setFormatPattern("0.000%");
			sheet.getCell("A11").getFormatHandle().setFormatPattern("0.0000%");
			sheet.getCell("A12").getFormatHandle().setFormatPattern("0.00000%");
			
			
			File file = new File(wd+"testFormatPatterns_out.xls");
			
			BufferedOutputStream stream = new BufferedOutputStream(new FileOutputStream(file));
			book.writeBytes(stream);
			stream.flush();
			stream.close();
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * @param i
	 * @return
	 */
	private static String getFormatString(int precision) {
		StringBuffer format = new StringBuffer("#,##0");
		if (precision > 0) {
			format.append(".");
		}
		for (int i = 0; i < precision; i++) {
			format.append("0");
		}
		return format.toString();
	}


}
