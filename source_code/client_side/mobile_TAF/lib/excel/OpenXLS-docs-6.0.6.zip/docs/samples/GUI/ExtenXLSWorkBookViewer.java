package docs.samples.GUI;

import com.extentech.ExtenXLS.*;
import com.extentech.ExtenXLS.ui.*;
import javax.swing.*;
import com.extentech.toolkit.*;
import java.awt.*;
import java.awt.event.*;
import com.extentech.swingtools.*;
import com.jgoodies.plaf.FontSizeHints;
import com.jgoodies.plaf.Options;
import com.jgoodies.plaf.plastic.Plastic3DLookAndFeel;
import com.jgoodies.plaf.plastic.PlasticLookAndFeel;
import com.jgoodies.plaf.plastic.PlasticTheme;
import com.jgoodies.plaf.plastic.theme.SkyBluerTahoma;


/** A basic WorkBook User Interface
 	<br>
 	Provides basic formatting, execution of formulas, ability to add and edit Cells, and ability
 	to create new, edit existing, and save WorkBooks.	
  	<br>
 	<br>
      @author John McMahon -- Copyright &copy;2006 <a href = "http://www.extentech.com">Extentech Inc.</a>
      @version 4.1
*/
public class ExtenXLSWorkBookViewer extends JFrame implements com.extentech.toolkit.ExceptionListener{

	private String	workingdir = "testfiles/"; // where your files live
	private ResourceLoader res = new ResourceLoader();
	private ImageIcon imageIcon2, imageIcon3;
	/** Constructor which takes a file path.
	 * 
	 * @param finp path to file to open
	 */
	public ExtenXLSWorkBookViewer(String finp){
		super("ExtenXLS " + WorkBookHandle.getVersion());
		init(finp + " :: " + finp);
		SymWindow aSymWindow= new SymWindow();
		this.addWindowListener(aSymWindow);
	}

	/** Entry point for WorkBook UI
	 * 
	 * @param args file to open
	 */
	public static void main(String[] args){
		String finp = "template.xls";
		if(args.length>0)finp = args[0];
		ExtenXLSWorkBookViewer t = new ExtenXLSWorkBookViewer(finp);
	}
    
	/**
	 * Sets the Look and Feel using JGoodies Plastic Look and Feel.
	 */
	public void initUI() {
		// fixes swing redraw issues...
		System.getProperties().put("sun.java2d.noddraw", "true");
		boolean classicLNF= false;
	//	Silver lnf = new Silver();
		SkyBluerTahoma lnf = new SkyBluerTahoma();
		try {// INIT JGoodies LNF
			UIManager.put("JSplitPaneWrapperUI","PlasticSplitPaneWrapperUI");
			UIManager.put("Application.useSystemFontSettings",Boolean.TRUE);
			PlasticLookAndFeel.setTabStyle(PlasticLookAndFeel.TAB_STYLE_DEFAULT_VALUE);
			UIManager.put(Options.USE_SYSTEM_FONTS_APP_KEY, Boolean.TRUE);
			UIManager.put(Options.NO_ICONS_KEY, Boolean.TRUE);
			UIManager.put("ScrollBar.is3DEnabled", Boolean.TRUE);
			Plastic3DLookAndFeel plaf= new Plastic3DLookAndFeel();
			PlasticLookAndFeel.setMyCurrentTheme((PlasticTheme)lnf);
			PlasticLookAndFeel.setFontSizeHints(FontSizeHints.SYSTEM);
			UIManager.setLookAndFeel(plaf);
			
			// icons
			byte[]  imb = res.getBytesFromJar("/com/extentech/ExtenXLS/ui/images/watchlist_view.gif");
			ImageIcon imageIcon1 = new ImageIcon(imb);
			setIconImage(imageIcon1.getImage());
			
			imb = res.getBytesFromJar("/com/extentech/ExtenXLS/ui/images/properties.gif");
			imageIcon2 = new ImageIcon(imb);

			imb = res.getBytesFromJar("/com/extentech/ExtenXLS/ui/images/browser.gif");
			imageIcon3 = new ImageIcon(imb);
			
			this.setDefaultCloseOperation(EXIT_ON_CLOSE);
			
		} catch (Exception e) {this.showMessage( e.toString(), "ERROR: Problem setting plastic LNF.");}
	}
    
    /** Inits the Interface
     * 
     * @param finp
     * @param sheetnm
     */
    public void init(String finp){
       	this.initUI();
      	this.Splash();
      	finp = workingdir + finp;
		this.getContentPane().setLayout(null);
		JInternalFrame jinf = new JInternalFrame(finp);
		this.setSize(600,425);
		Dimension screenSize =
		Toolkit.getDefaultToolkit().getScreenSize();
		Dimension labelSize = this.getSize();
		this.setLocation(screenSize.width/2 - (labelSize.width/2),
					screenSize.height/2 - (labelSize.height/2));
		ExtenXLSPanel pan = new ExtenXLSPanel(jinf);
		pan.setExceptionListener(this);
		jinf.setSize(550,350);
		jinf.setLocation(25,25);
		jinf.setResizable(true);
		jinf.setIconifiable(true);
		jinf.setMaximizable(true);
		jinf.getContentPane().setLayout(new  java.awt.GridLayout(1,1));
		jinf.getContentPane().add(pan);
		jinf.setFrameIcon(imageIcon2);
		jinf.setVisible(true);
		
		// Create HTML Viewer
		BrowserInternalFrame bif = pan.getWorkBookPanel().getBrowser(); 
		bif.setTitle("Link Browser");
		bif.setSize(300,300);
		bif.setIconifiable(true);
//		bif.setClosable(true);
		bif.setResizable(true);
		bif.setFrameIcon(imageIcon3);
		bif.setVisible(false);
		
		this.getLayeredPane().add(bif);
		this.getLayeredPane().add(jinf);
		
		bif.moveToBack();
		jinf.moveToFront();
		
		this.setVisible(true);
		pan.openFile((java.awt.event.ActionEvent)null);

    }

	/**
	 *  Provides Splashing
	 *
	 */
	public void Splash(){
		JFrame fr = new JFrame();
		ResourceLoader res = new ResourceLoader();
		try{
			byte[] imgbytes = res.getBytesFromJar("/com/extentech/ExtenXLS/ui/images/splash_logo_silver.gif");
		SplashWindow splashy = new SplashWindow(imgbytes, fr, 5000);
		fr.setVisible(true);
		}catch(Exception e){System.err.println("ERROR: could not display splash screen: " + e);}
	}

	/** Exit this world.
	 * 
	 */
	void exitApplication(java.awt.event.WindowEvent event) {
		
	}
	
	public void exceptionThrown(Exception e){
		this.showMessage(e.toString(), "ExtenXLSWorkBookViewer ERROR");
	}
	
	// Close the window!
	class SymWindow extends java.awt.event.WindowAdapter {
		public void windowClosing(java.awt.event.WindowEvent event) {
			Object object= event.getSource();
			if (object == ExtenXLSWorkBookViewer.this)
				ExtenXLSWorkBookViewer_windowClosing(event);
		}
	}
	
	/** 
	 * Override to NOT close!
	 */
	protected void processWindowEvent(WindowEvent e) {
		if (e.getID() == WindowEvent.WINDOW_CLOSING) {
//			Beep
			 Toolkit.getDefaultToolkit().beep();
			 // Show a confirmation dialog
			 int reply=
				 JOptionPane.showConfirmDialog(
					 this,
					 "Exit Application?",
					 "ExtenXLS WorkBook Viewer",
					 JOptionPane.YES_NO_OPTION,
					 JOptionPane.QUESTION_MESSAGE);
			 // If the confirmation was affirmative, handle exiting.
			 if (reply == JOptionPane.YES_OPTION) {
				switch(this.getDefaultCloseOperation()) {
					case HIDE_ON_CLOSE:
						setVisible(false);
						break;
					case DISPOSE_ON_CLOSE:
						setVisible(false);
						dispose();
						break;
					case DO_NOTHING_ON_CLOSE:
						default: 
						break;
				  	case EXIT_ON_CLOSE:
					// This needs to match the checkExit call in
				  	// setDefaultCloseOperation
					System.exit(0);
					break;
				}
			 }
		}else{
			super.processWindowEvent(e);
		}
	}
	
	
	/**
	 * @param event
	 */
	void ExtenXLSWorkBookViewer_windowClosing(java.awt.event.WindowEvent event) {
		ExtenXLSWorkBookViewer_windowClosing_Interaction1(event);
	}

	/**
	 * @param event
	 */
	void ExtenXLSWorkBookViewer_windowClosing_Interaction1(
		java.awt.event.WindowEvent event) {
		try {
			this.exitApplication(event);
		} catch (Exception e) {}
	}

	/**
	 * 	Show a message dialog.
	 * 
	 * @param msg
	 * @param title
	 */
	public void showMessage(String msg, String title) {
		log(title + " : " + msg);
		try {
			Toolkit.getDefaultToolkit().beep();
			com.extentech.swingtools.JAttentionDialog dg=
				new com.extentech.swingtools.JAttentionDialog(this, title);
			msg=
				"The application reported the following error:"
					+ "\r\n\r\n"
					+ msg;
			dg.setText(msg);
			this.log(msg);
			Dimension screenSize =
			Toolkit.getDefaultToolkit().getScreenSize();
			Dimension labelSize = dg.getSize();
			dg.setLocation(screenSize.width/2 - (dg.getWidth()/2),
						screenSize.height/2 - (dg.getHeight()/2));
			dg.setVisible(true);
		} catch (Exception e) {
			System.out.println(e);
		}
	}
	
	/** Logs a message to System.out
	 */
	public void log(String msg) {
		java.util.Date now = new java.util.Date(System.currentTimeMillis());
		System.out.println(now + " - ExtenXLSWorkBookViewer: " + msg);
	}
}
