﻿package docs.samples.SalaryServlet;


import com.extentech.ExtenXLS.*;
import com.extentech.formats.XLS.*;
import com.extentech.toolkit.Logger;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;

/* Copyright 2004 Extentech Inc.
EXTENTECH SOFTWARE LICENSE AGREEMENT

All Java classes and other files contained in the com.extentech package are protected
by copyright and are the sole property of Extentech Inc.

This software may be used only by Extentech customers and may not be copied, sold, distributed
or used for any other purpose without the prior written consent of Extentech.  Those
interested in licensing components, servlets, and utility classes separately from the Luminet
Server product should contact Extentech Inc. at sales@extentech.com.

You agree that you will not reverse-engineer, or decompile the compiled files distributed with
this program with the exception of open-source servlets and other files with which source code
is included in the distribution.

To the maximum extent permitted by law, Extentech Inc. disclaims all warranties regarding
this software, expressed or implied, including but not limited to warranties of merchantability
and fitness for a particular purpose. In no event shall Extentech be liable for special,
consequential, incidental or indirect damages arising out of the use or inability
to use this software even if Extentech Inc. is aware of the possibility of such
damages or known defects.

This software is provided AS IS.
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.

By using this software, you are agreeing to all of the terms of this license.
****************************************************/
/** A Sample Servlet demonstrating ExtenXLS usage in a Servlet application.

      @author John McMahon -- Copyright &&copy;2006<a href = "http://www.extentech.com">Extentech Inc.</a>
      @version 4.1
    @since 1.3
*/
public class SalarySurveyServlet extends javax.servlet.http.HttpServlet{

    WorkBookHandle book;
    String finpath = "";
    
    public void init(){
    	// replace this with the absolute file path to your template 
        finpath = "/usr/projects/salarysurvey/SalarySurvey.xls";
     	int debuglev = 0; // > 0 will provide debug info to System.out.
        book = new WorkBookHandle(finpath, debuglev);
    }

    public void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException
    {
      	try{
      	    // get handles to the cells
      	    WorkSheetHandle sheet1 = book.getWorkSheet("Sheet1");
      	    CellHandle nameCell = sheet1.getCell("E1");
      	    CellHandle titleCell = sheet1.getCell("B12");
      	    CellHandle salaryCell = sheet1.getCell("C12");

      	    // set the cell values
            nameCell.setVal("Tom Brown");
            titleCell.setVal(req.getParameter("Project Manager"));
            salaryCell.setVal(new Float(1000000));
      	    
        }catch (CellNotFoundException e){log("couldn't find cell" + e);
        }catch (WorkSheetNotFoundException e){log("couldn't find worksheet" + e);}
        res.setStatus(HttpServletResponse.SC_OK);
	    log( "Salary Survey called" );
	    res.setContentType("application/vnd.ms-excel");
      	if(false){
      	    String foutput = "surveyout.xls";
      	    testWrite(book,foutput);
	    }
		ServletOutputStream out = res.getOutputStream();
		book.writeBytes(out);
        out.flush();
        out.close();
    }
    
    public void testWrite(WorkBookHandle b, String fout){
        try{
      	    java.io.File f = new java.io.File(fout);
            FileOutputStream fos = new FileOutputStream(f);
            BufferedOutputStream bbout = new BufferedOutputStream(fos);
            b.writeBytes(bbout);
            bbout.flush();
		    fos.close();
      	} catch (java.io.IOException e){Logger.logInfo("IOException in Tester.  "+e);}  
    } 
    
}