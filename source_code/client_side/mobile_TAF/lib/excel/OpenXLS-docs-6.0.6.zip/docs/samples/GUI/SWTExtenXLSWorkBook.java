package docs.samples.GUI;

import com.extentech.ExtenXLS.*;
import com.extentech.ExtenXLS.ui.*;

import javax.swing.*;
import com.extentech.toolkit.*;
import java.awt.*;
import java.awt.event.*;
import com.extentech.swingtools.*;


import org.eclipse.swt.SWT;
import org.eclipse.swt.awt.SWT_AWT;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.layout.FormAttachment;
import org.eclipse.swt.layout.FormData;
import org.eclipse.swt.layout.FormLayout;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.layout.RowData;
import org.eclipse.swt.layout.RowLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

import java.io.*;

/** A basic WorkBook User Interface
 	<br>
 	Provides basic formatting, execution of formulas, ability to add and edit Cells, and ability
 	to create new, edit existing, and save WorkBooks.	
  	<br>
 	<br>
      @author John McMahon -- Copyright &copy;2006 <a href = "http://www.extentech.com">Extentech Inc.</a>
      @version 4.1
*/
public class SWTExtenXLSWorkBook{
    
    public static void main(String[] args) {
        SWTExtenXLSWorkBook.setFile("C:/eclipse/workspace/test/test.xls");
    }
    
    
    public static void setFile(String fileName) { 
    	    	    
    		Display display = Display.getDefault();
    		Shell shell = new Shell(display);
            FillLayout shellLayout = new FillLayout(org.eclipse.swt.SWT.HORIZONTAL);
            shell.setLayout(shellLayout);

    		SWTExtenXLSWorkBookViewer inst = new SWTExtenXLSWorkBookViewer(shell, SWT.CENTER);
    		Point size = inst.getSize();
            shell.layout();
    		if(size.x == 0 && size.y == 0) {
    			inst.pack();
    			shell.pack();
    		} else {
    			Rectangle shellBounds = shell.computeTrim(0, 0, size.x, size.y);
    			shell.setSize(shellBounds.width, shellBounds.height);
    		}

    		inst.init(fileName);
    		shell.open();
    		while (!shell.isDisposed()) {
    			if (!display.readAndDispatch())
    				display.sleep();
    		}
    	}
}