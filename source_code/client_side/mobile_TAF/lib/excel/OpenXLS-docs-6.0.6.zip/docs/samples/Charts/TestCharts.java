package docs.samples.Charts;

/** Demonstration of Chart handling
 * 
      @author John McMahon -- Copyright &copy;2007 <a href = "http://www.extentech.com">Extentech Inc.</a>
      @version 4.1
      * @since 1.3

    This Class Demonstrates the basic functionality of of ExtenXLS Chart Handling.

*/

import java.io.BufferedOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;

import com.extentech.ExtenXLS.*;
import com.extentech.formats.XLS.*;
import com.extentech.toolkit.Logger;

public class TestCharts {


	public static void main(String[] args){
		TestCharts t = new TestCharts();
		t.testCharts();
	}

/** Test the operation of the ChartHandle functions

	@author John McMahon
	@version 1.0
*/

	public ChartHandle ct = null;
	private String finpath ="",sheetname="", foutpath="";
	/** read in an XLS file, work with Sheets
	*/
	public void testCharts(){
		// these are the files to test
		String[] testfiles = {
			"testChart1.xls","Sheet1",
		};
		for(int i = 0;i<testfiles.length;i++){
			if(false){
				java.io.File logfile = new java.io.File("extenxls" + i +".log");        
				try{
					BufferedOutputStream sysout = new BufferedOutputStream( new FileOutputStream(logfile));
					System.setOut(new PrintStream(sysout));
				}catch (IOException e){System.out.println("IOE: " + e);}
			}
			finpath = testfiles[i];
			sheetname = testfiles[++i];
			System.out.println("testReadWrite" + String.valueOf(i) + " =====================> " + finpath + ":" + sheetname);
			doit(finpath, sheetname);
			testNewChart();
			System.out.println("testReadWrite DONE");
		}
	}
	
	
	/**
	 * Creates a new Chart in a new WorkBook.
	 * <p><p>
	 */
	public void testNewChart() {
	    WorkBookHandle book = new WorkBookHandle();
		// attempt to create a new Chart
		WorkSheetHandle sheet = null;
		try{
			sheet = book.getWorkSheet("Sheet1");
		}catch(WorkSheetNotFoundException e){
			Logger.logErr(e);
		}
		sheet.add(new Integer(212), "A1");
		sheet.add(new Integer(54), "A2");
		sheet.add(new Integer(212), "B1");
		sheet.add(new Integer(54), "B2");
		book.createChart("NEWCHART", sheet);
		
		try {
			ChartHandle cht = book.getChart("NEWCHART");
			cht.setChartType(ChartHandle.BUBBLE);
		}catch(Exception ex) {
		    Logger.logErr("Problem accessing new chart.", ex);
		}
		this.testWrite(book, "NewChartOut.xls");
	    
	}

	public void doit(String finp, String sheetnm){
		WorkBookHandle book = new WorkBookHandle(finp);
		WorkSheetHandle sheet = null;
		try{
			sheet = book.getWorkSheet(sheetnm);
			WorkSheetHandle[] handles = book.getWorkSheets();
			ChartHandle[] charts = book.getCharts();
			for (int i=0; i<charts.length; i++) {
				System.out.println("Found Chart: " + charts[i]);
			}
			sheet.add(new Integer(4),"A4");
			sheet.add(new Integer(5),"A5");
			sheet.add(new Integer(14),"B4");
			sheet.add(new Integer(15),"B5");
			sheet.add(new Integer(24),"C4");
			sheet.add(new Integer(25),"C5");
	
			try{
				 ct = book.getChart("Test Chart");
			}catch (ChartNotFoundException e){
				System.out.println(e);
			}
			sheet.add(new Float(103.256),"F23");
			sheet.add(new Integer(125),"G23");
			
			if(ct.changeSeriesRange("Sheet1!C23:E23", "Sheet1!C23:G23"));
			System.out.println("Successfully Changed Series Range!");
			
			sheet.add("D","F24");
			sheet.add("E","G24");
			if(ct.changeCategoryRange("Sheet1!C24:E24", "Sheet1!C24:G24"));
			System.out.println("Successfully Changed Categories Range!");
			
			if(ct.changeTextValue("Category X", "Widget Class"));
			System.out.println("Successfully Changed Categories Label!");
			
			if(ct.changeTextValue("Value Y", "Sales Totals"));
			System.out.println("Successfully Changed Values Label!");
			
			ct.setChartTitle("New Chart Title!");
			System.out.println("Chart Name: "+ ct);
	
			foutpath = finp +"output.xls"  ;
			
			// Copy the worksheet
			book.copyWorkSheet("Sheet2", "SheetNEW");
			
			// Copy the Chart
			try{
				book.copyChartToSheet("New Chart Title!", "SheetNEW");
			}catch(Exception e){
				System.out.println(e);
			}
			
			testWrite(book, foutpath);
			WorkBookHandle b2 = new WorkBookHandle(foutpath);
		}catch(WorkSheetNotFoundException e){
			System.out.println(e);
		}
	}

	 
    public void testWrite(WorkBookHandle b, String fout){
        try{
      	    java.io.File f = new java.io.File(fout);
            FileOutputStream fos = new FileOutputStream(f);
            BufferedOutputStream bbout = new BufferedOutputStream(fos);
            b.writeBytes(bbout);
            bbout.flush();
		    fos.close();
      	} catch (java.io.IOException e){Logger.logInfo("IOException in Tester.  "+e);}  
    }  

}
