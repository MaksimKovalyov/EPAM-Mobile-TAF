package docs.samples.Formulas;

import com.extentech.ExtenXLS.*;
import com.extentech.formats.XLS.*;
import com.extentech.toolkit.Logger;

import java.io.*;

/* Copyright 2002 Extentech Inc.
EXTENTECH SOFTWARE LICENSE AGREEMENT

All Java classes and other files contained in the com.extentech package are protected
by copyright and are the sole property of Extentech Inc.

This software may be used only by Extentech customers and may not be copied, sold, distributed
or used for any other purpose without the prior written consent of Extentech.  Those
interested in licensing components, servlets, and utility classes separately from the Luminet
Server product should contact Extentech Inc. at sales@extentech.com.

You agree that you will not reverse-engineer, or decompile the compiled files distributed with
this program with the exception of open-source servlets and other files with which source code
is included in the distribution.

To the maximum extent permitted by law, Extentech Inc. disclaims all warranties regarding
this software, expressed or implied, including but not limited to warranties of merchantability
and fitness for a particular purpose. In no event shall Extentech be liable for special,
consequential, incidental or indirect damages arising out of the use or inability
to use this software even if Extentech Inc. is aware of the possibility of such
damages or known defects.

This software is provided AS IS.
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.

By using this software, you are agreeing to all of the terms of this license.
****************************************************/

/**
      @author Nick Rab -- Copyright &copy;2006 <a href = "http://www.extentech.com">Extentech Inc.</a>
      @version 4.1
 * @since 1.3

    This Class Demonstrates the functionality of of ExtenXLS Formula manipulation.

*/

public class TestFormulas{

    public static void main(String[] args){
        testformula t = new testformula();
		String s = "Test Successful.";
		if(args.length>0)s = args[0];
		t.testFormula();
    }
}

/** Test the manipulation of Formulas within a worksheet.
*/
class testformula{
    WorkBookHandle book = null;
    WorkSheetHandle sheet = null;
    String sheetname = "Sheet1", finpath = "testFormula.xls", workingdir = "C:/ExtenXLS3/";
    
	/** thrash multiple changes to formula references and recalc
	 * ------------------------------------------------------------
	 * 
	 * @author John [ Oct 26, 2007 ]
	 */
	public void testMultiChange() {
		try {
			Logger.logInfo("Testing multiple changes to formula references and recalc");
			WorkBookHandle wbx = new WorkBookHandle();
			WorkSheetHandle sheet1 = wbx.getWorkSheet(0);
			sheet1.add(new Double(100.123),"A1");
			sheet1.add(new Double(200.123),"A2");
			CellHandle cx = sheet1.add("=sum(A1*A2)","A3");
			Logger.logInfo(String.valueOf(cx));
			Logger.logInfo("start setting 100k vals");
			for(int t=0;t<100000;t++) {
					sheet1.getCell("A1").setVal(Math.random()*10000);
					sheet1.getCell("A2").setVal(Math.random()*10000);
					Object calced = cx.getVal();	
					Logger.logInfo(calced.toString());
			}
			Logger.logInfo("done setting 100k vals");
			ExtenXLS.writeBookToFile("/bookout.xls",wbx);
			
		}catch(Exception ex) {
			Logger.logErr("testFormulas.testMultiChange: " + ex.toString());
		}
	}
    
    /** Demonstrates Dynamic Formula Calculation
     * 
     *
     */
	public void calcit(){
		try{
			this.doit(finpath, sheetname);
			// c4 + d4 = f4
			CellHandle mycell1 = sheet.getCell("C4");
			CellHandle mycell2 = sheet.getCell("D4");
			CellHandle myformulacell = sheet.getCell("F4");
			
			// output the calculated values
			FormulaHandle form = myformulacell.getFormulaHandle();
			System.out.println(form.calculate().toString());

			// change the values then recalc			
			mycell1.setVal(99);
			mycell2.setVal(420);
			System.out.println(form.calculate().toString());
			
			testWrite();
		}catch(CellNotFoundException e){System.out.println("cell not found" + e);
		}catch(FormulaNotFoundException e){System.out.println("No formula to change" + e);
		}catch(Exception e){
			System.out.println(e);
		}
	}
    
    /**
     * Move a Cell Reference within a Formula
     *
     */
    public void changeSingleCellLoc(){
        try{
            this.doit(finpath, sheetname);
            CellHandle mycell = sheet.getCell("A10");   
            FormulaHandle form = mycell.getFormulaHandle();
            form.changeFormulaLocation("A3", "G10");
            testWrite();
        }catch(CellNotFoundException e){System.out.println("cell not found" + e);
        }catch(FormulaNotFoundException e){System.out.println("No formula to change" + e);}
    }
    
    /**
     * Move a Cell range reference within a Formula
     *
     */
    public void testHandlerFunctions(){
        try{
            this.doit(finpath, sheetname);
            CellHandle mycell = sheet.getCell("E8");   
            FormulaHandle myhandle = mycell.getFormulaHandle();
            boolean b = myhandle.changeFormulaLocation("A1:B2", "D1:D28");
            testWrite();
        }catch(CellNotFoundException e){System.out.println("cell not found" + e);} 
        catch(FormulaNotFoundException e){System.out.println("No formula to change" + e);}
    } 
    
    /**
     * Add a cell to a Cell range reference within a Formula
     *
     */
    public void testCellHandlerFunctions(){
        try{
            this.doit(finpath, sheetname);
            CellHandle mycell = sheet.getCell("E8");   
            CellHandle secondcell = sheet.getCell("D19");
            FormulaHandle myhandle = mycell.getFormulaHandle();
            boolean b = myhandle.addCellToRange("A1:B2", secondcell);
            testWrite();
        }catch(CellNotFoundException e){System.out.println("cell not found" + e);} 
        catch(FormulaNotFoundException e){System.out.println("No formula to change" + e);}
    } 
    
    /**
     * Run tests
     *
     */
    public void testFormula(){
        try{
            String finpath = "testformularange3.xls";
            String sheetname = "Option Grant Data";
            this.doit(finpath, sheetname);
            sheet.removeRow(2,true);
            testWrite();
        }catch(Exception e){System.out.println("Exception in testFORMULA.testFormulaSeries(): " + e);}
    }

	WorkSheetHandle sht = null;
		void testFormulaCalc(String fs, String sh){    
			WorkBookHandle book = new WorkBookHandle(fs);
			sheetname = sh;
			try{
				sht = book.getWorkSheet(sheetname);
			}catch(Exception e){System.out.println(e);}
        
			FormulaHandle f = null;
			Double i = null;
        
			/************************************
			 * Formula Parse test
			 **************************************/
			if (sheetname.equalsIgnoreCase("Sheet1")){
				try{
				
					// one ref & ptgadd
					sht.add(null, "A1");
					CellHandle c = sht.getCell("A1");
					c.setFormula("b1+5");
					f = c.getFormulaHandle();
					i = (Double)f.calculate();
				
					// two refs & ptgadd
					sht.add(null, "A2");
					c = sht.getCell("A2");
					c.setFormula("B1+ A1");
					f  = c.getFormulaHandle();
					i = (Double)f.calculate();
				
					// ptgsub
					f.setFormula("B1 - 5");
					i = (Double)f.calculate();
				
					// ptgmul
					f.setFormula("D1 * F1");
					i = (Double)f.calculate();
				
					// ptgdiv
					f.setFormula("E1 / F1");
					i = (Double)f.calculate();

					// ptgpower
					f.setFormula("E1 ^ F1");
					i = (Double)f.calculate();
				
					f.setFormula("E1 > F1");
					Boolean b = (Boolean)f.calculate();
				
					f.setFormula("E1 >= F1");
					b = (Boolean)f.calculate();
				
					f.setFormula("E1 < F1");
					b = (Boolean)f.calculate();
				
					f.setFormula("E1 <= F1");
					b = (Boolean)f.calculate();

					f.setFormula("Pi()");
					i = (Double)f.calculate();
				
					f.setFormula("LOG(10,2)");
					i = (Double)f.calculate();
					System.out.println(i.toString());
				
					f.setFormula("ROUND(32.443,1)");
					i = (Double)f.calculate();
					System.out.println(i.toString());
				
					f.setFormula("MOD(45,6)");
					i = (Double)f.calculate();
					System.out.println(i.toString());
			
					f.setFormula("DATE(1998,2,4)");
					i = (Double)f.calculate();
					System.out.println(i.toString());
				
					f.setFormula("SUM(1998,2,4)");
					i = (Double)f.calculate();
					System.out.println(i.toString());

					f.setFormula("IF(TRUE,1,0)");
					i = (Double)f.calculate();
					System.out.println(i.toString());

					f.setFormula("ISERR(\"test\")");
					b = (Boolean)f.calculate();
					System.out.println(b.toString());
				
					// many operand ptgfuncvar
					f.setFormula("SUM(12,3,2,4,5,1)");
					i = (Double)f.calculate();
					System.out.println(i.toString());
					
					// test with a sub-calc
					f.setFormula("IF((1<2),1,0)");
					i = (Double)f.calculate();
					System.out.println(i.toString());

					f.setFormula("IF((1<2),MOD(45,6),1)");
					i = (Double)f.calculate();
					System.out.println(i.toString());
				
					f.setFormula("IF((1<2),if((true),8,1),1)");
					i = (Double)f.calculate();
					System.out.println(i.toString());
				
					f.setFormula("IF((SUM(23,2,3,4)<12),if((true),8,1),DATE(1998,2,4))");
					i = (Double)f.calculate();
					System.out.println(i.toString());
				
				}catch(CellNotFoundException e){System.out.println(e);}
				catch(FunctionNotSupportedException e){System.out.println(e);}
				catch(Exception e){System.out.println(e);}
				testWrite();
				String s = "CellHandle";
			}
		}

    public void doit(String finp, String sheetnm){
      	book = new WorkBookHandle(finp);
       try{ sheet = book.getWorkSheet(sheetnm);
       }catch (WorkSheetNotFoundException e){System.out.println("couldn't find worksheet" + e);}

    }

    public void testWrite(){
        try{
      	    java.io.File f = new java.io.File("testFormulaOut.xls");
            FileOutputStream fos = new FileOutputStream(f);
            BufferedOutputStream bbout = new BufferedOutputStream(fos);
            book.writeBytes(bbout);
            bbout.flush();
		    fos.close();
      	} catch (java.io.IOException e){Logger.logInfo("IOException in Tester.  "+e);}  
    }

}