package docs.samples.XMLInput;

import java.io.*;

import com.extentech.ExtenXLS.*;

import org.jdom.Document;
import org.jdom.output.XMLOutputter;
import com.extentech.ExtenBean.*;
import com.extentech.toolkit.Logger;

import java.util.*;


/** Demonstrate the operation of XML -> XSL -> * tranformations.

	Requires JDOM package from www.jdom.org

      @author John McMahon -- Copyright &copy;2006 <a href = "http://www.extentech.com">Extentech Inc.</a>
      @version 4.1
*/
public class Transform
{
    

    public static void main(String[] args){
        Transform t = new Transform();
		String s = "Test Successful.";
		if(args.length>0)s = args[0];
		t.transform();
    }
    
    private WorkBookHandle book;
    private String finpath = "", xmlfile = "", 
    workingdir = "C://ExtenXLS4/docs/samples/XMLInput/"; // change for your installation path
    
	/** read in an XLS file transform it and output the new file
	*/
	public void transform(){
        
		// source xls file and xsl file
		String[] testfiles = {
			 "Contacts.xls","Contacts.xml",
		};
       
		for(int i = 0;i<testfiles.length;i++){
			if(false){
				java.io.File logfile = new java.io.File("extenxls" + i +".log");        
				try{
					BufferedOutputStream sysout = new BufferedOutputStream( new FileOutputStream(logfile));
					System.setOut(new PrintStream(sysout));
				}catch (IOException e){System.out.println("IOE: " + e);}
			}
			finpath = testfiles[i];
			System.out.println("====================== TEST Transform: " + String.valueOf(i) + " ======================");
			xmlfile = testfiles[++i];
			System.out.println("=====================> " + finpath + ":" + xmlfile);
			doit(finpath, xmlfile);
			this.testWrite(book,finpath+".out");
			System.out.println("TEST XMLInput DONE");
		}
		
        
	}

    void doit(String xlsfile, String xmlfile){
		book = new WorkBookHandle(workingdir + xlsfile);
		WorkSheetHandle sheet = null;
		try {
		    sheet = book.getWorkSheet("Sheet1");
		}catch(Exception e) {
		    System.err.println(e);
		}
		
		
		// get the XML content into an XMLDataObject
		// see the com.extentech.ExtenBean API docs for information on the DataBean API
		XMLDataObjectFactory factory = new XMLDataObjectFactory();
		factory.setXMLFile(workingdir + xmlfile, true);
		DataObject data = new XMLDataObject();
		data.setKeyCol("TestID");
        data.setFactory(factory);
        try{
            data.load();
        
			// data starts at D6
			Vector dt = data.getChildObjects();
			for(int t=0;t<dt.size();t++) {
			    DataObject child = (DataObject)dt.get(t);
			    Vector cd = child.getChildObjects();
			    
			    // insert a new row, copying the formats
			    sheet.insertRow(6+t, true);
			    
			    // set the data vals in the appropriate cells
			    String addy = "D"+(6+t);	// create the cell address for the data
			    child = (DataObject)cd.get(0);
			    sheet.setVal(addy, new Integer(Integer.parseInt((String)child.getVal("TestID"))));
			    
			    addy = "E" + (6+t);
			    child = (DataObject)cd.get(1);
			    sheet.setVal(addy, child.getVal("Order_Mnemonic"));
			    
			    addy = "F" + (6+t);
			    child = (DataObject)cd.get(2);
			    sheet.setVal(addy, child.getVal("Alias"));
			    
			    addy = "G" + (6+t);
			    child = (DataObject)cd.get(3);
			    sheet.setVal(addy, child.getVal("CPT4"));
			    
			    addy = "H" + (6+t);
			    child = (DataObject)cd.get(4);
			    sheet.setVal(addy, child.getVal("Specimen_Required"));

			    addy = "I" + (6+t);
			    child = (DataObject)cd.get(5);
			    sheet.setVal(addy, child.getVal("Specimen_Type"));
			    
			    addy = "J" + (6+t);
			    child = (DataObject)cd.get(6);
			    sheet.setVal(addy, child.getVal("Container"));
			    
			    addy = "K" + (6+t);
			    child = (DataObject)cd.get(7);
			    sheet.setVal(addy, child.getVal("Special_Handling"));
			    
			    addy = "L" + (6+t);
			    child = (DataObject)cd.get(8);
			    sheet.setVal(addy, child.getVal("Min_Vol"));
			    
			    addy = "M" + (6+t);
			    child = (DataObject)cd.get(9);
			    sheet.setVal(addy, child.getVal("Min_Vol_Units"));
			    
			    addy = "N" + (6+t);
			    child = (DataObject)cd.get(10);
			    sheet.setVal(addy, child.getVal("Transfer_Temp"));
			    
			    addy = "O" + (6+t);
			    child = (DataObject)cd.get(11);
			    sheet.setVal(addy, child.getVal("Performing_Location"));
			    
			    addy = "P" + (6+t);
			    child = (DataObject)cd.get(12);
			    sheet.setVal(addy, child.getVal("Viewable_By"));
			    
			    addy = "Q" + (6+t);
			    child = (DataObject)cd.get(13);
			    sheet.setVal(addy, new Integer(Integer.parseInt(((String)child.getVal("Action_Flag")).trim())));

			}
        }catch(Throwable e){
            throw new RuntimeException("Problem reading and setting XML data from file: " + data + ": " +e);
        }
				
		// stream the workbook to a byte array
		testWrite(book,workingdir +  "OUTPUT-" + xlsfile);
    }

    
	/** output the DOM to file
	*/
	private boolean writeFile(Document d, String xp){
		try{
			FileOutputStream f = new FileOutputStream(new File(xp));
			XMLOutputter xout = new XMLOutputter();
			xout.getFormat().setIndent("  "); // use two space indent
			xout.getFormat().setLineSeparator("\r\n"); 
			xout.output(d, f);
		}catch(Exception e){
			System.out.println("Error Writing XML DataObject to file: " + e);
			return false;
		} 
		return true;
	}
    
 
    public void testWrite(WorkBookHandle b, String fout){
        try{
      	    java.io.File f = new java.io.File(fout);
            FileOutputStream fos = new FileOutputStream(f);
            BufferedOutputStream bbout = new BufferedOutputStream(fos);
            b.writeBytes(bbout);
            bbout.flush();
		    fos.close();
      	} catch (java.io.IOException e){Logger.logInfo("IOException in Tester.  "+e);}  
    }  
    
    
}