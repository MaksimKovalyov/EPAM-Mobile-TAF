## Documentation Now Available Online ##

In an effort to provide our users with the most up-to-date information, and to create 
a more interactive developer environment, Extentech has moved all product documentation online.

By providing access to our most current documentation, bug reports, build reports, 
feature requests, and demos & sample code, we hope to create a lively resource which 
provides a tight feedback loop to our product developers as well as to other customers.

In that spirit, please leave comments on any articles if there is anything we can do to 
provide you with better products and service.

## Quick Links ##

New Features in OpenXLS:
http://www.extentech.com/docs_detail.jsp?page_meme_type=20&meme_id=1327
------------------------------------------------------------------------

Online Product Documentation in Book Form:
http://extentech.sheetster.com/index.jsp
------------------------------------------------------------------------

Latest Builds, Build Reports, and Changelogs:
http://www.extentech.com/docs_home.jsp?page_meme_type=27&page_meme_type_name=Build%20Reports
------------------------------------------------------------------------

FAQs:
http://www.extentech.com/docs_home.jsp?page_meme_type=2&page_meme_type_name=FAQ
------------------------------------------------------------------------

## Additional Support ##

Extentech is committed to being the most customer-centric company in the industry.

We hope you find our new developer network useful and comprehensive.  Most articles allow you to
leave comments for the article authors, ensuring that your questions are answered.

If you would like to speak to us, please call us anytime at (415) 759-5292.

Any sales and support issues can be emailed to sales@extentech.com or support@extentech.com